import React from "react";

function App() {
  return (
    <div className="App">
      <h1>Welcome to the Messaging Service</h1>
    </div>
  );
}

export default App;
