from fastapi import APIRouter

router = APIRouter()

@router.post("/")
def create_group():
    return {"message": "Group created"}

@router.get("/{group_id}")
def get_group_messages(group_id: int):
    return {"messages": f"Messages for group {group_id}"}
