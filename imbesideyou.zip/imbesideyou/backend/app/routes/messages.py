from fastapi import APIRouter

router = APIRouter()

@router.post("/")
def send_message():
    return {"message": "Message sent"}

@router.get("/{user_id}")
def get_messages(user_id: int):
    return {"messages": f"Messages for user {user_id}"}
