from pydantic import BaseModel
from typing import List, Optional

class User(BaseModel):
    id: int
    username: str
    email: str
    password: str

class Message(BaseModel):
    sender_id: int
    receiver_id: int
    content: str
    timestamp: str

class Group(BaseModel):
    id: int
    name: str
    members: List[int]
