from fastapi import FastAPI
from app.routes import auth, messages, groups

app = FastAPI()

# Include routes
app.include_router(auth.router, prefix="/auth")
app.include_router(messages.router, prefix="/messages")
app.include_router(groups.router, prefix="/groups")

@app.get("/")
def read_root():
    return {"message": "Welcome to the Messaging Service API"}
